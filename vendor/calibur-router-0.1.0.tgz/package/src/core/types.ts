/**
 * CalibURRouter 核心类型定义
 * 
 * 基于集合论的类型安全模式匹配引擎的类型系统
 */

/** 后端无关的状态空间模式；后端负责集合运算，核心链只携带推断状态。 */
export interface 状态空间模式<out 状态 = unknown> {
    readonly infer: 状态;
}

/** 从任意状态空间模式提取其运行时状态。 */
export type PatternState<Pattern extends 状态空间模式> = Pattern["infer"];

/** 将模式对象形状投影为对应的运行时状态对象。 */
export type PatternShapeState<Shape extends Readonly<Record<string, 状态空间模式>>> = {
    -readonly [Key in keyof Shape]: PatternState<Shape[Key]>;
};

/** 所有形式化 Schema 后端共同支持的 JSON 原子状态。 */
export type FormalUnit = string | number | boolean | null;

/** Schema 后端必须提供的完整运行时状态空间代数。 */
export interface StateSpaceBackend {
    readonly name: string;
    assertPattern(pattern: 状态空间模式): void;
    describe(pattern: 状态空间模式): string;
    match<状态>(pattern: 状态空间模式<状态>, input: unknown): 状态 | null;
    isSubset(left: 状态空间模式, right: 状态空间模式): boolean;
    overlaps(left: 状态空间模式, right: 状态空间模式): boolean;
    covers(universe: 状态空间模式, patterns: readonly 状态空间模式[]): boolean;
}

/** 绑定单个 Schema 后端的 Calibur 路由入口。 */
export interface CaliburRouter {
    universe<全集>(全集模式: 状态空间模式<全集>): 匹配器构建器<全集, never>;
}

// ============================================================================
// 基础类型
// ============================================================================

/**
 * 模式处理器类型
 * @template 模式 - 输入模式的类型（由 Schema 后端推断）
 * @template 结果 - 处理器返回值类型
 */
export type 处理器<模式, 结果> = (输入: 模式) => 结果;

/**
 * 已注册的模式-处理器对
 */
export interface 已注册模式<模式 = unknown, 结果 = unknown> {
    /** Schema 后端的模式定义 */
    模式: 状态空间模式<模式>;
    /** 对应的处理器 */
    处理器: 处理器<模式, 结果>;
}

/**
 * 分发器函数类型
 * @template 输入 - 输入类型（全集）
 * @template 输出 - 所有处理器返回类型的联合
 * 
 * 分发器携带 `__全集模式__` 属性，用于嵌套时验证子集关系
 */
export interface 分发器<输入, 输出> {
    (输入: 输入): 输出;
    /** 携带的全集模式，用于嵌套验证 */
    __全集模式__: 状态空间模式<输入>;
    /** 创建该分发器的 Schema 后端，用于阻断跨后端嵌套。 */
    __状态空间后端__: StateSpaceBackend;
}

/**
 * 检查一个值是否为分发器
 */
export type 是分发器<T> = T extends 分发器<infer _U, infer _R> ? true : false;

/**
 * 提取分发器的全集类型
 */
export type 提取分发器全集<T> = T extends 分发器<infer U, infer _R> ? U : never;

// ============================================================================
// 类型工具
// ============================================================================

/**
 * 检查对象类型中是否包含 never 类型的属性（递归检测）
 * 
 * 解决 TypeScript 中 { a: never } extends never 为 false 的问题。
 * 如果一个对象的某个必需属性是 never，那么这个对象实际上无法实例化（为空集）。
 */
type 包含Never属性<T> = T extends object
    ? {
        [K in keyof T]-?: [T[K]] extends [never]
        ? true  // 属性本身是 never
        : 包含Never属性<T[K]> // 递归检查子属性
    }[keyof T] extends false
    ? false
    : true
    : false;



/**
 * 过滤掉包含 never 属性的对象类型
 * 用于从联合类型中移除不可能的状态
 */
export type 过滤无效对象<T> = T extends any
    ? 包含Never属性<T> extends true ? never : T
    : never;

/**
 * 计算两个集合的差集 (T - U)
 * 
 * 对于对象类型：
 * T - U = Union(T where key K is (T[K] - U[K])) for all K in U
 * 
 * 原理：(A & B)' = A' U B'
 * 我们想要 T & Not(U)
 * Not(U) = Union(Not(U[K]))
 * 所以 T & Not(U) = Union(T & Not(U[K]))
 */
type 原始集合差<T, U> = T extends object
    ? U extends object
    ? {
        [K in keyof U & keyof T]: {
            [P in keyof T]: P extends K ? 切割后剩余<T[P], U[P & keyof U]> : T[P]
        }
    }[keyof U & keyof T]
    : Exclude<T, U>
    : Exclude<T, U>;

/**
 * 从剩余集中排除已切割的模式
 * 这是类型级别的集合差运算
 */
export type 切割后剩余<剩余集, 已切割模式> = 过滤无效对象<原始集合差<剩余集, 已切割模式>>;

/** 按注册顺序一次性计算剩余空间，避免每个链式 split 重复展开全部历史集合差。 */
export type 应用切割序列<剩余集, 已切割列表 extends readonly unknown[]> =
    已切割列表 extends readonly [infer 当前模式, ...infer 后续模式]
    ? 应用切割序列<切割后剩余<剩余集, 当前模式>, 后续模式>
    : 剩余集;

/**
 * 检查剩余集是否为空（never）
 */
export type 剩余集为空<剩余集> = [剩余集] extends [never] ? true : false;

/** 已覆盖模式联合包含全集时，路由构建器立即进入耗尽态。 */
export type 全集已覆盖<全集, 已覆盖模式> =
    [全集] extends [已覆盖模式] ? true : false;

/**
 * 检查两个类型的交集是否非空（用于编译期重叠检测）
 * 
 * 逻辑：
 * 1. 计算交集 A & B
 * 2. 如果交集本身是 never，返回 false
 * 3. 如果交集是对象且包含 never 属性（如 { kind: "a" } & { kind: "b" } -> { kind: never }），返回 false
 * 4. 否则返回 true
 */
export type 交集非空<A, B> =
    [A & B] extends [never] ? false :
    包含Never属性<A & B> extends true ? false :
    true;

/**
 * 检查新模式是否与已覆盖模式联合中的任意成员有交集。
 * 联合由 TypeScript 直接分发，避免长 split 链持续扩张历史元组并递归遍历。
 */
export type 与已覆盖模式有交集<模式, 已覆盖模式> =
    [已覆盖模式] extends [never]
    ? false
    : 交集非空<模式, 已覆盖模式>;

/**
 * 类型错误标记：当模式与已切割模式有重叠时，返回此类型
 * 
 * 使用方式：将 split 的参数类型设置为条件类型，
 * 当检测到重叠时返回错误消息类型
 */
export type 断言模式无重叠<模式, 已覆盖模式> =
    与已覆盖模式有交集<模式, 已覆盖模式> extends true
    ? ["❌ 类型错误：模式与已切割模式有重叠", {
        新模式: 模式,
        已覆盖模式: 已覆盖模式,
        提示: "请确保 split 的模式互不重叠，或使用嵌套分发器处理子集关系"
    }]
    : 模式;

/**
 * 类型层面的子集检测
 * 
 * 如果 A 的所有可能值都是 B 的可能值，则 A 是 B 的子集
 * 在 TypeScript 中，这大致对应于 A extends B
 */
export type 是子集类型<子集, 父集> = 子集 extends 父集 ? true : false;

/**
 * 检查子分发器的全集是否合法
 * 
 * @template 子全集 - 子分发器的全集类型
 * @template 剩余集 - 当前剩余集类型（用于错误提示）
 * @template 模式定义 - 当前 split 的模式类型
 * @template 严格模式 - 是否启用严格模式
 * 
 * 非严格模式（默认）：只检查子全集与模式定义有交集
 * 严格模式：检查子全集是模式定义的严格子集（子全集 extends 模式定义）
 */
export type 断言子分发器全集合法<子全集, 剩余集, 模式定义, 严格模式 extends boolean = false> =
    严格模式 extends true
    // 严格模式：检查子全集是否是模式定义的子集
    ? 是子集类型<子全集, 模式定义> extends false
    ? ["❌ 类型错误：子分发器全集不是当前模式的子集（严格模式）", {
        子分发器全集: 子全集,
        当前模式: 模式定义,
        剩余集: 剩余集,
        提示: "严格模式要求子分发器的全集必须是当前模式的严格子集"
    }]
    : 子全集
    // 非严格模式：只检查有交集
    : 交集非空<子全集, 模式定义> extends false
    ? ["❌ 类型错误：子分发器全集与当前模式无交集", {
        子分发器全集: 子全集,
        当前模式: 模式定义,
        剩余集: 剩余集,
        提示: "子分发器的全集必须与当前模式有交集"
    }]
    : 子全集;

/**
 * 深度合并类型：将全集与模式合并
 * - 模式中指定的属性使用模式中更窄的类型（类型收窄）
 * - 模式中未指定的属性保留全集中的类型
 * 
 * 这允许用户只用部分属性定义模式，同时处理器能享受类型收窄并访问全集的所有属性
 * 
 * @example
 * type 全集 = { 名称: string, 等级: number }
 * type 模式 = { 等级: 10 }  // 只指定等级
 * type 合并后 = 合并类型<全集, 模式>
 * // = { 名称: string, 等级: 10 }  // 名称保留，等级收窄
 */
export type 合并类型<全集, 模式> =
    全集 extends object
    ? 模式 extends object
    ? {
        // 对于全集中的每个键
        [K in keyof 全集]: K extends keyof 模式
        // 如果模式中也有这个键，递归合并（支持嵌套对象）
        ? 合并类型<全集[K], 模式[K]>
        // 否则保留全集中的类型
        : 全集[K]
    }
    // 如果模式不是对象，直接使用模式类型（类型收窄）
    : 模式
    // 如果全集不是对象，使用模式类型（类型收窄）
    : 模式;

/**
 * 匹配器构建器接口
 * 提供链式API用于定义模式分发规则
 * 
 * @template 全集 - 全集类型
 * @template 结果联合 - 当前结果类型联合
 * @template 已切割列表 - 已切割模式的有序序列，仅在 remain/build 边界求值
 * @template 已覆盖模式 - 已切割模式的联合，用于增量互斥检查
 */
export interface 匹配器构建器<
    全集,
    结果联合,
    已切割列表 extends readonly unknown[] = [],
    已覆盖模式 = never,
> {
    /**
     * 切割子集并注册处理器
     * 类型系统会自动从剩余集中排除已切割的模式
     * 
     * 编译期检测：如果新模式与已切割模式有重叠，会在类型层面报错
     * 
     * @param 模式 - Schema 模式定义（用于匹配筛选，可以只指定部分属性）
     * @param 处理器 - 匹配该模式时的处理函数
     * @returns 更新后的匹配器构建器（剩余集已缩小，已切割列表已更新）
     */
    split<模式定义, 新结果>(
        // 使用条件类型：如果新模式与已切割模式有交集，返回错误类型
        模式: 断言模式无重叠<模式定义, 已覆盖模式> extends 模式定义
            ? 状态空间模式<模式定义>
            : 断言模式无重叠<模式定义, 已覆盖模式>,
        处理器: 处理器<合并类型<全集, 模式定义>, 新结果> & { __全集模式__?: never }
    ): 全集已覆盖<全集, 已覆盖模式 | 合并类型<全集, 模式定义>> extends true
        ? 耗尽的匹配器构建器<全集, 结果联合 | 新结果>
        : 匹配器构建器<
            全集,
            结果联合 | 新结果,
            [...已切割列表, 模式定义],
            已覆盖模式 | 合并类型<全集, 模式定义>
        >;

    /**
     * 切割子集并委托给嵌套分发器
     * 当使用分发器作为处理器时，必须提供fallback处理器来处理模式中未被子分发器覆盖的部分
     */
    split<模式定义, 子全集, 子结果, Fallback结果>(
        模式: 断言模式无重叠<模式定义, 已覆盖模式> extends 模式定义
            ? 状态空间模式<模式定义>
            : 断言模式无重叠<模式定义, 已覆盖模式>,
        子分发器: 断言子分发器全集合法<子全集, 全集, 模式定义> extends 子全集
            ? 分发器<子全集, 子结果>
            : 断言子分发器全集合法<子全集, 全集, 模式定义>,
        fallback处理器: 处理器<合并类型<全集, 模式定义>, Fallback结果>
    ): 全集已覆盖<全集, 已覆盖模式 | 合并类型<全集, 模式定义>> extends true
        ? 耗尽的匹配器构建器<全集, 结果联合 | 子结果 | Fallback结果>
        : 匹配器构建器<
            全集,
            结果联合 | 子结果 | Fallback结果,
            [...已切割列表, 模式定义],
            已覆盖模式 | 合并类型<全集, 模式定义>
        >;

    /**
     * 处理剩余模式
     * 当其他split都不匹配时调用
     */
    remain<新结果>(
        处理器: 处理器<应用切割序列<全集, 已切割列表>, 新结果>
    ): 可构建匹配器<全集, 结果联合 | 新结果>;

    /** 处理剩余空间但不读取其状态，避免无意义的剩余集类型展开。 */
    otherwise<新结果>(
        处理器: () => 新结果
    ): 可构建匹配器<全集, 结果联合 | 新结果>;

    /**
     * 构建分发器
     */
    build: 剩余集为空<应用切割序列<全集, 已切割列表>> extends true
        ? () => 分发器<全集, 结果联合>
        : never;
}

/**
 * 耗尽的匹配器构建器
 * 当剩余集为空时返回此接口，禁止继续调用 split 或 remain
 */
export interface 耗尽的匹配器构建器<全集, 结果联合> {
    /**
     * 构建分发器
     */
    build(): 分发器<全集, 结果联合>;
}

/**
 * 可构建的匹配器（已处理所有模式）
 */
export interface 可构建匹配器<全集, 结果联合> {
    /**
     * 构建最终的分发器函数
     */
    build(): 分发器<全集, 结果联合>;
}

// ============================================================================
// 工具类型导出
// ============================================================================

/**
 * 从后端无关的状态空间模式中提取推断类型
 */
export type 推断类型<T extends 状态空间模式> = PatternState<T>;
